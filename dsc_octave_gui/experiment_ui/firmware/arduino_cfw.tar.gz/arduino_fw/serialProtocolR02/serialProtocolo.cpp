#include "Arduino.h"
#include <string.h>
#include "serialProtocol.h"
#define tblSinLen 100

const unsigned int tblSin[tblSinLen] = 
{
  0x0200, 0x0220, 0x0240, 0x025f, 0x027f, 0x029e, 0x02bc, 0x02d9, 0x02f6, 0x0312, 
  0x032c, 0x0346, 0x035e, 0x0375, 0x038a, 0x039e, 0x03b0, 0x03c0, 0x03cf, 0x03dc, 
  0x03e6, 0x03ef, 0x03f6, 0x03fb, 0x03fe, 0x0400, 0x03fe, 0x03fb, 0x03f6, 0x03ef, 
  0x03e6, 0x03dc, 0x03cf, 0x03c0, 0x03b0, 0x039e, 0x038a, 0x0375, 0x035e, 0x0346, 
  0x032c, 0x0312, 0x02f6, 0x02d9, 0x02bc, 0x029e, 0x027f, 0x025f, 0x0240, 0x0220, 
  0x0200, 0x01df, 0x01bf, 0x01a0, 0x0180, 0x0161, 0x0143, 0x0126, 0x0109, 0x00ed, 
  0x00d3, 0x00b9, 0x00a1, 0x008a, 0x0075, 0x0061, 0x004f, 0x003f, 0x0030, 0x0023, 
  0x0019, 0x0010, 0x0009, 0x0004, 0x0001, 0x0000, 0x0001, 0x0004, 0x0009, 0x0010, 
  0x0019, 0x0023, 0x0030, 0x003f, 0x004f, 0x0061, 0x0075, 0x008a, 0x00a1, 0x00b9, 
  0x00d3, 0x00ed, 0x0109, 0x0126, 0x0143, 0x0161, 0x0180, 0x01a0, 0x01bf, 0x01df
};


unsigned int getSinValue(void)
{
  static unsigned int idxSin = 0;  
  unsigned int ret;
  ret = tblSin[idxSin];
  idxSin++;
  idxSin = idxSin % tblSinLen;
  return ret;
}


/***
 * aNanoSetPinType(obj, numeroPin, tipo, argumentos)
 * obj: corresponde con el que se establece la comunicación.
 * numeroPin: identificación del pin.
 * tipo: “digital” 
 * Los argumentos pueden ser “output”(1),“inputPullUp”(2), “inputFloat” o “input” (3).
 * El paquete de datos, para pines digitales, se construye como:
 * 0xB0, CMD = 1, nroPin, tipo 1 - 3, 0, 0, 0, suma, 0x0b
 */

void doCMD01(protocolData *c)
{  
  if((c->data[0] >= 2) && (c->data[0] <= 19))
  {
    if (c->data[1] == 1)
      pinMode(c->data[0], OUTPUT);
    else if(c->data[1] == 2)
      pinMode(c->data[0], INPUT_PULLUP);
    else if(c->data[1] == 3)
      pinMode(c->data[0], INPUT);
  }
}

/***
 * aNanoAnalogRead(obj, numeroPin)
 * obj: corresponde con el que se establece la comunicación.
 * numeroPin: identificación del pin.
 * Retorna el valor resultante de la conversión. Los pines que se consideran como válidos son numerados del 14 (A0) al 21 (A7) y el 1 que genera una señal senoidal por software.
 * El paquete de datos, para pines digitales, se construye como:
 * 0xB0, CMD = 2, nroPin, 0, 0, 0, 0, suma, 0x0b
 * Retorna 2 bytes representando el valor resultante de la conversión.
 */
void doCMD02(protocolData *c)
{
  unsigned int val = 0;
  unsigned char b0, b1;
  if (c->data[0] == 1)
    val = getSinValue();
  else if((c->data[0] >= 14) && (c->data[0] <= 21))
    val = analogRead(c->data[0]);
  b0 = val & 0xFF;
  val = val >> 8;
  b1 = val & 0xFF;
  Serial.write(b0);
  Serial.write(b1);
}

/***
 * aNanoDigitalRead(obj, numeroPin)
 * obj: corresponde con el que se establece la comunicación.
 * numeroPin: identificación del pin.
 * Retorna el valor resultante de la conversión. Los pines que se consideran como válidos son numerados del 2 al 19.
 * El paquete de datos, para pines digitales, se construye como:
 * 0xB0, CMD = 3, nroPin, 0, 0, 0, 0, suma, 0x0b
 * Retorna 1 bytes representando el valor presente.
*/

void doCMD03(protocolData *c)
{
  unsigned char val = 0;
  if((c->data[0] >= 2) && (c->data[0] <= 19))
    val = digitalRead(c->data[0]);  
  Serial.write(val);
}

/***
 * aNanoAnalogWrite(obj, numeroPin, val)
 * obj: corresponde con el que se establece la comunicación.
 * numeroPin: identificación del pin.
 * Val: un valor de 0 a 255 estableciendo el ciclo útil.
 * Los pines válidos para esta función son 3, 5, 6, 9, 10, 11.
 * El paquete de datos, para pines digitales, se construye como:
 * 0xB0, CMD = 4, nroPin, val, 0, 0, 0, suma, 0x0b
 */
void doCMD04(protocolData *c)
{
  if((c->data[0] == 3) || 
     (c->data[0] == 5) || 
     (c->data[0] == 6) || 
     (c->data[0] == 9) || 
     (c->data[0] == 10) || 
     (c->data[0] == 11))
     analogWrite(c->data[0], c->data[1]);
  
}

/***
 * aNanoDigitalWrite(obj, numeroPin, val)
 * obj: corresponde con el que se establece la comunicación.
 * numeroPin: identificación del pin.
 * Val: 0 para falso y diferente de cero para cualquier otro valor.
 * El paquete de datos, para pines digitales, se construye como:
 * 0xB0, CMD = 5, nroPin, val, 0, 0, 0, suma, 0x0b
 */
void doCMD05(protocolData *c)
{
  if((c->data[0] >= 2) && (c->data[0] <= 19))
  {
    if(c->data[1])
      digitalWrite(c->data[0], HIGH);
    else
      digitalWrite(c->data[0], LOW);
  }
}

const doCMD cmdActionList[17] =
{
  doCMD01, //  0
  doCMD02, //  1
  doCMD03, //  2
  doCMD04, //  3
  doCMD05
};

//
// Detecta el encabezado
//

void stageHeader(protocolData* b, unsigned char val)
{
  if(val == 0xB0)
  {
    b->crc = 0xB0;    
    b->dataInx = 0;
    b->nextState = STATE_CMD;
  }
  else
    b->nextState = STATE_HEADER;
}
//
// Carga CMD
//
void stageCMD(protocolData* b, unsigned char val)
{
  if((val >= FIRST_CMD) && (val <= LAST_CMD))  
  {
    b->crc += val;
    b->cmd = val;
    b->nextState = STATE_DATA;
  }
  else
    b->nextState = STATE_HEADER;
}

//
// Carga payload
//
void stageDATA(protocolData* b, unsigned char val)
{  
  b->data[b->dataInx] = val;
  b->crc += val;
  b->dataInx ++;
  if(b->dataInx == 5)
    b->nextState = STATE_CRC;
}

//
// verifica CRC (ojo, no incluye el marcador de fin de paquete 0x0B
//
void stageCRC(protocolData* b, unsigned char val)
{ 
  if(b->crc == val)
    b->nextState = STATE_FOOTER;
  else
    b->nextState = STATE_HEADER;
}

//
// Verifica fin de paquete y ejecuta la orden asociada.
//
void stageFOOTER(protocolData* b, unsigned char val)
{
  if(val == 0x0B)
  {
    if((b->cmd >= FIRST_CMD) && (b->cmd <= LAST_CMD))
      cmdActionList[b->cmd - FIRST_CMD](b);
  }
  b->nextState = STATE_HEADER;
}


const stageFunc allStages[5] = 
{
  stageHeader, // 0
  stageCMD,    // 1
  stageDATA,   // 2
  stageCRC,    // 3  
  stageFOOTER  // 4
};

void initProtocol(protocolData *p)
{
  memset(p, 0, sizeof(protocolData));
}

void decodeProtocol(protocolData *p, unsigned char newVal)
{
  allStages[p->nextState](p, newVal);
}



